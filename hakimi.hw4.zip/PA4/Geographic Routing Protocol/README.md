# Geographic Routing Protocol

#### How to Compile and Run:

Compile by simply running `g++ -std=c++17 -lstdc++ main.cpp Node.cpp Router.cpp -o gf`

#### How to run:

Simply use this command with the appropriate info filled in
`./gf gf.conf x y z`